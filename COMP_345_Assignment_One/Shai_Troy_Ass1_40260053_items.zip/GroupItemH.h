#ifndef GroupItemH.h
#define GroupItemH.h

#include "Item.h"
#include "TreasureChest.h"
#include "Equipment.h"
#include "Backpack.h"
#include "Armor.h"
#include "Belt.h"
#include "Helmet.h"
#include "Ring.h"
#include "Shield.h"
#include "Weapon.h"

#endif